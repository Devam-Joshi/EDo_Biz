@include('layouts.mail.header')
@yield('content')
@include('layouts.mail.footer')
