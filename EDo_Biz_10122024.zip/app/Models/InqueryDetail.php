<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class InqueryDetail extends Model
{
   protected $table = 'tbl_sale_inquery_detail';
}

