<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SerialNo extends Model
{
	protected $table = 'tbl_serialnumber';
    
}
