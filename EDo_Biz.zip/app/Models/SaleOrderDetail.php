<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SaleOrderDetail extends Model
{
   protected $table = 'tbl_sale_order_detail';
}
