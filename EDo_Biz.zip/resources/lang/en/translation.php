<?php

return [
    "Menu" => "Menu",
    "Dashboards" => "Dashboards",
    "Profile" => "Profile",
    "Logout" => "Logout",

];
